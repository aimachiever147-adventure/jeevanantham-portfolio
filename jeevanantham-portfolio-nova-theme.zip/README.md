# Jeevanantham C. — Professional Portfolio

A refreshed, responsive NOVA-style personal portfolio for GitHub Pages. Lightweight static HTML/CSS/JS, no framework, build step, backend, or paid hosting. Uses system fonts to avoid remote font-loading delays.

## Before publishing
1. Add your approved professional photograph as `assets/profile.jpg`.
2. In `index.html`, replace `YOUR_EMAIL@example.com` with the email address you want public.
3. Add verified LinkedIn / ORCID / Google Scholar links only when ready.
4. Review the biography and academic-status wording carefully. Do not claim completed qualifications, registration, publications, awards, or clinical outcomes unless verified.
5. Optional: replace the portrait placeholder in `index.html` with:
   `<img class="profile-photo" src="assets/profile.jpg" alt="Portrait of Jeevanantham C.">`
   Then add `.profile-photo{width:100%;height:100%;object-fit:cover;}` to `styles.css`, and remove the `portrait-placeholder` div.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `jeevanantham-portfolio` (or `YOUR-USERNAME.github.io` for a user-site repository).
2. Upload the contents of this folder (not the folder itself) to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. The URL will be `https://YOUR-USERNAME.github.io/jeevanantham-portfolio/` for a project site, or `https://YOUR-USERNAME.github.io/` for a user site.

GitHub Pages provides free hosting for public repositories on GitHub Free. A custom domain is optional and costs extra; the default `github.io` address is free.

## Important
This is a static portfolio template. It does not include a contact form backend. The email link opens the visitor's email application. Do not publish private phone numbers, home addresses, certificates containing sensitive identifiers, or unverified professional claims.
